from .main import criar_projeto_flask
import re, sys, os

nome_projeto = input("Project name: ")
criar_projeto_flask(nome_projeto)
