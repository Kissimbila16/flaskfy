This is a lib to help generate flask apps with custom components


# Instalation 

```bash
pip install flaskfy
```

# Creating new flask project

```bash
createflaskapp
```